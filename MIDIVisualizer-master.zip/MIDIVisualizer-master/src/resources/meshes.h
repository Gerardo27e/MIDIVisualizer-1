#ifndef MESH_RESOURCES_H
#define MESH_RESOURCES_H

#include <vector>

extern const std::vector<float> pedalsVertices;
extern const std::vector<unsigned int> pedalsIndices;


#endif
